﻿namespace ECB_APP
{
    partial class frm_hotel_H_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_title = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_input = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_units = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_cla = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pnl_result = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_3 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lbl_2 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_1 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_t_1 = new System.Windows.Forms.Label();
            this.lbl_t_2 = new System.Windows.Forms.Label();
            this.lbl_t_3 = new System.Windows.Forms.Label();
            this.pnl_title.SuspendLayout();
            this.pnl_input.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnl_result.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_title
            // 
            this.pnl_title.BackColor = System.Drawing.Color.Black;
            this.pnl_title.Controls.Add(this.label2);
            this.pnl_title.Controls.Add(this.label1);
            this.pnl_title.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_title.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnl_title.Location = new System.Drawing.Point(0, 0);
            this.pnl_title.Name = "pnl_title";
            this.pnl_title.Size = new System.Drawing.Size(791, 74);
            this.pnl_title.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(791, 22);
            this.label2.TabIndex = 1;
            this.label2.Text = "Customer Category H-1";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(791, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "HOTEL PURPOSE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_input
            // 
            this.pnl_input.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.pnl_input.Controls.Add(this.panel2);
            this.pnl_input.Controls.Add(this.panel1);
            this.pnl_input.Controls.Add(this.label3);
            this.pnl_input.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_input.Location = new System.Drawing.Point(0, 74);
            this.pnl_input.Name = "pnl_input";
            this.pnl_input.Size = new System.Drawing.Size(791, 58);
            this.pnl_input.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txt_units);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(339, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(330, 58);
            this.panel2.TabIndex = 4;
            // 
            // txt_units
            // 
            this.txt_units.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_units.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_units.Location = new System.Drawing.Point(6, 20);
            this.txt_units.Name = "txt_units";
            this.txt_units.Size = new System.Drawing.Size(318, 23);
            this.txt_units.TabIndex = 0;
            this.txt_units.Text = "0";
            this.txt_units.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_units.Click += new System.EventHandler(this.txt_units_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_cla);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(669, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(122, 58);
            this.panel1.TabIndex = 3;
            // 
            // btn_cla
            // 
            this.btn_cla.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cla.Location = new System.Drawing.Point(8, 15);
            this.btn_cla.Name = "btn_cla";
            this.btn_cla.Size = new System.Drawing.Size(104, 32);
            this.btn_cla.TabIndex = 0;
            this.btn_cla.Text = "CALCULATE ";
            this.btn_cla.UseVisualStyleBackColor = true;
            this.btn_cla.Click += new System.EventHandler(this.btn_cla_Click);
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(339, 58);
            this.label3.TabIndex = 2;
            this.label3.Text = "No of Units Consumed in last 30 days";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_result
            // 
            this.pnl_result.Controls.Add(this.tableLayoutPanel2);
            this.pnl_result.Controls.Add(this.tableLayoutPanel1);
            this.pnl_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_result.Location = new System.Drawing.Point(0, 132);
            this.pnl_result.Name = "pnl_result";
            this.pnl_result.Size = new System.Drawing.Size(791, 388);
            this.pnl_result.TabIndex = 3;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.11205F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.484143F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.4038F));
            this.tableLayoutPanel2.Controls.Add(this.lbl_3, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.label26, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label25, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl_2, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.label23, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label22, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_1, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label20, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label19, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 100);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(791, 288);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // lbl_3
            // 
            this.lbl_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_3.Location = new System.Drawing.Point(526, 192);
            this.lbl_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_3.Name = "lbl_3";
            this.lbl_3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_3.Size = new System.Drawing.Size(265, 96);
            this.lbl_3.TabIndex = 11;
            this.lbl_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label26
            // 
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(467, 192);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(59, 96);
            this.label26.TabIndex = 10;
            this.label26.Text = "=";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(0, 192);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label25.Size = new System.Drawing.Size(467, 96);
            this.label25.TabIndex = 9;
            this.label25.Text = "Total Charge (Rs)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_2
            // 
            this.lbl_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_2.Location = new System.Drawing.Point(526, 96);
            this.lbl_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_2.Name = "lbl_2";
            this.lbl_2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_2.Size = new System.Drawing.Size(265, 96);
            this.lbl_2.TabIndex = 8;
            this.lbl_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(467, 96);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(59, 96);
            this.label23.TabIndex = 7;
            this.label23.Text = "=";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(0, 96);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label22.Size = new System.Drawing.Size(467, 96);
            this.label22.TabIndex = 6;
            this.label22.Text = "Fixed Charges (Rs)";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_1
            // 
            this.lbl_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_1.Location = new System.Drawing.Point(526, 0);
            this.lbl_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_1.Size = new System.Drawing.Size(265, 96);
            this.lbl_1.TabIndex = 5;
            this.lbl_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(467, 0);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(59, 96);
            this.label20.TabIndex = 4;
            this.label20.Text = "=";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(0, 0);
            this.label19.Margin = new System.Windows.Forms.Padding(0);
            this.label19.Name = "label19";
            this.label19.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label19.Size = new System.Drawing.Size(467, 96);
            this.label19.TabIndex = 3;
            this.label19.Text = "Charge for Units (Rs)";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t_1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t_2, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t_3, 2, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 30F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(791, 100);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(1, 1);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(262, 55);
            this.label5.TabIndex = 1;
            this.label5.Text = "Energy Charge (LKR/kWh)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(264, 1);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(262, 55);
            this.label6.TabIndex = 2;
            this.label6.Text = "Fixed Charge (LKR/month)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(527, 1);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(263, 55);
            this.label7.TabIndex = 3;
            this.label7.Text = "Maximum Demand Charge per Month (LKR/kVA)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t_1
            // 
            this.lbl_t_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_1.Location = new System.Drawing.Point(1, 57);
            this.lbl_t_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_1.Name = "lbl_t_1";
            this.lbl_t_1.Size = new System.Drawing.Size(262, 42);
            this.lbl_t_1.TabIndex = 5;
            this.lbl_t_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t_2
            // 
            this.lbl_t_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_2.Location = new System.Drawing.Point(264, 57);
            this.lbl_t_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_2.Name = "lbl_t_2";
            this.lbl_t_2.Size = new System.Drawing.Size(262, 42);
            this.lbl_t_2.TabIndex = 6;
            this.lbl_t_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t_3
            // 
            this.lbl_t_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t_3.Location = new System.Drawing.Point(527, 57);
            this.lbl_t_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t_3.Name = "lbl_t_3";
            this.lbl_t_3.Size = new System.Drawing.Size(263, 42);
            this.lbl_t_3.TabIndex = 7;
            this.lbl_t_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frm_hotel_H_1
            // 
            this.AcceptButton = this.btn_cla;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 520);
            this.Controls.Add(this.pnl_result);
            this.Controls.Add(this.pnl_input);
            this.Controls.Add(this.pnl_title);
            this.Name = "frm_hotel_H_1";
            this.Text = "frm_hotel_H_1";
            this.Load += new System.EventHandler(this.frm_hotel_H_1_Load);
            this.pnl_title.ResumeLayout(false);
            this.pnl_input.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.pnl_result.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_title;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_input;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_units;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_cla;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnl_result;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lbl_3;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbl_2;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_t_1;
        private System.Windows.Forms.Label lbl_t_2;
        private System.Windows.Forms.Label lbl_t_3;
    }
}