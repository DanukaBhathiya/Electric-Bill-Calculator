﻿namespace ECB_APP
{
    partial class frm_domestic_Billrate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_title = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_result = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_t2_10 = new System.Windows.Forms.Label();
            this.lbl_t2_5 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.lbl_t2_9 = new System.Windows.Forms.Label();
            this.lbl_t2_4 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.lbl_t2_8 = new System.Windows.Forms.Label();
            this.lbl_t2_3 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lbl_t2_7 = new System.Windows.Forms.Label();
            this.lbl_t2_2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_t2_1 = new System.Windows.Forms.Label();
            this.lbl_t2_6 = new System.Windows.Forms.Label();
            this.lbl_subtitle2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label27 = new System.Windows.Forms.Label();
            this.lbl_t1_4 = new System.Windows.Forms.Label();
            this.lbl_t1_2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_t1_1 = new System.Windows.Forms.Label();
            this.lbl_t1_3 = new System.Windows.Forms.Label();
            this.lbl_subtitle1 = new System.Windows.Forms.Label();
            this.pnl_title.SuspendLayout();
            this.pnl_result.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_title
            // 
            this.pnl_title.BackColor = System.Drawing.Color.Black;
            this.pnl_title.Controls.Add(this.label2);
            this.pnl_title.Controls.Add(this.label1);
            this.pnl_title.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_title.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnl_title.Location = new System.Drawing.Point(0, 0);
            this.pnl_title.Name = "pnl_title";
            this.pnl_title.Size = new System.Drawing.Size(791, 58);
            this.pnl_title.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(791, 22);
            this.label2.TabIndex = 1;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(791, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "DOMESTIC PURPOSE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_result
            // 
            this.pnl_result.Controls.Add(this.tableLayoutPanel2);
            this.pnl_result.Controls.Add(this.lbl_subtitle2);
            this.pnl_result.Controls.Add(this.tableLayoutPanel1);
            this.pnl_result.Controls.Add(this.lbl_subtitle1);
            this.pnl_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_result.Location = new System.Drawing.Point(0, 58);
            this.pnl_result.Name = "pnl_result";
            this.pnl_result.Size = new System.Drawing.Size(791, 462);
            this.pnl_result.TabIndex = 4;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 3;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel2.Controls.Add(this.label3, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_10, 2, 5);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_5, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label24, 0, 5);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_9, 2, 4);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_4, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label21, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_8, 2, 3);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_3, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label18, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_7, 2, 2);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_2, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label4, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label8, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.label12, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.label13, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_1, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lbl_t2_6, 2, 1);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 170);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 6;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(791, 292);
            this.tableLayoutPanel2.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1, 97);
            this.label3.Margin = new System.Windows.Forms.Padding(0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(262, 47);
            this.label3.TabIndex = 20;
            this.label3.Text = "61 - 90";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_10
            // 
            this.lbl_t2_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_10.Location = new System.Drawing.Point(527, 241);
            this.lbl_t2_10.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_10.Name = "lbl_t2_10";
            this.lbl_t2_10.Size = new System.Drawing.Size(263, 50);
            this.lbl_t2_10.TabIndex = 19;
            this.lbl_t2_10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_5
            // 
            this.lbl_t2_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_5.Location = new System.Drawing.Point(264, 241);
            this.lbl_t2_5.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_5.Name = "lbl_t2_5";
            this.lbl_t2_5.Size = new System.Drawing.Size(262, 50);
            this.lbl_t2_5.TabIndex = 18;
            this.lbl_t2_5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(1, 241);
            this.label24.Margin = new System.Windows.Forms.Padding(0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(262, 50);
            this.label24.TabIndex = 17;
            this.label24.Text = ">180";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_9
            // 
            this.lbl_t2_9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_9.Location = new System.Drawing.Point(527, 193);
            this.lbl_t2_9.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_9.Name = "lbl_t2_9";
            this.lbl_t2_9.Size = new System.Drawing.Size(263, 47);
            this.lbl_t2_9.TabIndex = 16;
            this.lbl_t2_9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_4
            // 
            this.lbl_t2_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_4.Location = new System.Drawing.Point(264, 193);
            this.lbl_t2_4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_4.Name = "lbl_t2_4";
            this.lbl_t2_4.Size = new System.Drawing.Size(262, 47);
            this.lbl_t2_4.TabIndex = 15;
            this.lbl_t2_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(1, 193);
            this.label21.Margin = new System.Windows.Forms.Padding(0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(262, 47);
            this.label21.TabIndex = 14;
            this.label21.Text = "121 - 180\t";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_8
            // 
            this.lbl_t2_8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_8.Location = new System.Drawing.Point(527, 145);
            this.lbl_t2_8.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_8.Name = "lbl_t2_8";
            this.lbl_t2_8.Size = new System.Drawing.Size(263, 47);
            this.lbl_t2_8.TabIndex = 13;
            this.lbl_t2_8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_3
            // 
            this.lbl_t2_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_3.Location = new System.Drawing.Point(264, 145);
            this.lbl_t2_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_3.Name = "lbl_t2_3";
            this.lbl_t2_3.Size = new System.Drawing.Size(262, 47);
            this.lbl_t2_3.TabIndex = 12;
            this.lbl_t2_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(1, 145);
            this.label18.Margin = new System.Windows.Forms.Padding(0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(262, 47);
            this.label18.TabIndex = 11;
            this.label18.Text = "91 - 120";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_7
            // 
            this.lbl_t2_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_7.Location = new System.Drawing.Point(527, 97);
            this.lbl_t2_7.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_7.Name = "lbl_t2_7";
            this.lbl_t2_7.Size = new System.Drawing.Size(263, 47);
            this.lbl_t2_7.TabIndex = 10;
            this.lbl_t2_7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_2
            // 
            this.lbl_t2_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_2.Location = new System.Drawing.Point(264, 97);
            this.lbl_t2_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_2.Name = "lbl_t2_2";
            this.lbl_t2_2.Size = new System.Drawing.Size(262, 47);
            this.lbl_t2_2.TabIndex = 9;
            this.lbl_t2_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label4.Location = new System.Drawing.Point(1, 1);
            this.label4.Margin = new System.Windows.Forms.Padding(0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(262, 47);
            this.label4.TabIndex = 1;
            this.label4.Text = "Consumption per month (kMh)";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(264, 1);
            this.label8.Margin = new System.Windows.Forms.Padding(0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(262, 47);
            this.label8.TabIndex = 2;
            this.label8.Text = "Energy Charge (LKR/kWh)";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(527, 1);
            this.label12.Margin = new System.Windows.Forms.Padding(0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(263, 47);
            this.label12.TabIndex = 3;
            this.label12.Text = "Fixed Charge (LKR/month)";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(1, 49);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(262, 47);
            this.label13.TabIndex = 5;
            this.label13.Text = "0 - 60";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_1
            // 
            this.lbl_t2_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_1.Location = new System.Drawing.Point(264, 49);
            this.lbl_t2_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_1.Name = "lbl_t2_1";
            this.lbl_t2_1.Size = new System.Drawing.Size(262, 47);
            this.lbl_t2_1.TabIndex = 6;
            this.lbl_t2_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t2_6
            // 
            this.lbl_t2_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t2_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t2_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t2_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t2_6.Location = new System.Drawing.Point(527, 49);
            this.lbl_t2_6.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t2_6.Name = "lbl_t2_6";
            this.lbl_t2_6.Size = new System.Drawing.Size(263, 47);
            this.lbl_t2_6.TabIndex = 7;
            this.lbl_t2_6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_subtitle2
            // 
            this.lbl_subtitle2.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_subtitle2.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subtitle2.Location = new System.Drawing.Point(0, 135);
            this.lbl_subtitle2.Name = "lbl_subtitle2";
            this.lbl_subtitle2.Size = new System.Drawing.Size(791, 35);
            this.lbl_subtitle2.TabIndex = 3;
            this.lbl_subtitle2.Text = "If the consumption is above 60 kWh per month";
            this.lbl_subtitle2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.label27, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t1_4, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t1_2, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.label6, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t1_1, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_t1_3, 2, 1);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 35);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(791, 100);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(1, 67);
            this.label27.Margin = new System.Windows.Forms.Padding(0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(262, 32);
            this.label27.TabIndex = 11;
            this.label27.Text = "31 - 60";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t1_4
            // 
            this.lbl_t1_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t1_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t1_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t1_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t1_4.Location = new System.Drawing.Point(527, 67);
            this.lbl_t1_4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t1_4.Name = "lbl_t1_4";
            this.lbl_t1_4.Size = new System.Drawing.Size(263, 32);
            this.lbl_t1_4.TabIndex = 10;
            this.lbl_t1_4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t1_2
            // 
            this.lbl_t1_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t1_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t1_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t1_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t1_2.Location = new System.Drawing.Point(264, 67);
            this.lbl_t1_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t1_2.Name = "lbl_t1_2";
            this.lbl_t1_2.Size = new System.Drawing.Size(262, 32);
            this.lbl_t1_2.TabIndex = 9;
            this.lbl_t1_2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label5.Location = new System.Drawing.Point(1, 1);
            this.label5.Margin = new System.Windows.Forms.Padding(0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(262, 32);
            this.label5.TabIndex = 1;
            this.label5.Text = "Consumption per month (kMh)";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label6.Location = new System.Drawing.Point(264, 1);
            this.label6.Margin = new System.Windows.Forms.Padding(0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(262, 32);
            this.label6.TabIndex = 2;
            this.label6.Text = "Energy Charge (LKR/kWh)";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label7.Location = new System.Drawing.Point(527, 1);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(263, 32);
            this.label7.TabIndex = 3;
            this.label7.Text = "Fixed Charge (LKR/month)";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(1, 34);
            this.label9.Margin = new System.Windows.Forms.Padding(0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(262, 32);
            this.label9.TabIndex = 5;
            this.label9.Text = "0 - 30";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t1_1
            // 
            this.lbl_t1_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t1_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t1_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t1_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t1_1.Location = new System.Drawing.Point(264, 34);
            this.lbl_t1_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t1_1.Name = "lbl_t1_1";
            this.lbl_t1_1.Size = new System.Drawing.Size(262, 32);
            this.lbl_t1_1.TabIndex = 6;
            this.lbl_t1_1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_t1_3
            // 
            this.lbl_t1_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lbl_t1_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_t1_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_t1_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_t1_3.Location = new System.Drawing.Point(527, 34);
            this.lbl_t1_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_t1_3.Name = "lbl_t1_3";
            this.lbl_t1_3.Size = new System.Drawing.Size(263, 32);
            this.lbl_t1_3.TabIndex = 7;
            this.lbl_t1_3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_subtitle1
            // 
            this.lbl_subtitle1.Dock = System.Windows.Forms.DockStyle.Top;
            this.lbl_subtitle1.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_subtitle1.Location = new System.Drawing.Point(0, 0);
            this.lbl_subtitle1.Name = "lbl_subtitle1";
            this.lbl_subtitle1.Size = new System.Drawing.Size(791, 35);
            this.lbl_subtitle1.TabIndex = 2;
            this.lbl_subtitle1.Text = "If the consumption is between 0-60 kWh per month";
            this.lbl_subtitle1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frm_domestic_Billrate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 520);
            this.Controls.Add(this.pnl_result);
            this.Controls.Add(this.pnl_title);
            this.Name = "frm_domestic_Billrate";
            this.Text = "frm_domestic_Billrate";
            this.Load += new System.EventHandler(this.frm_domestic_Billrate_Load);
            this.pnl_title.ResumeLayout(false);
            this.pnl_result.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_title;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_result;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbl_t2_10;
        private System.Windows.Forms.Label lbl_t2_5;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label lbl_t2_9;
        private System.Windows.Forms.Label lbl_t2_4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label lbl_t2_8;
        private System.Windows.Forms.Label lbl_t2_3;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lbl_t2_7;
        private System.Windows.Forms.Label lbl_t2_2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_t2_1;
        private System.Windows.Forms.Label lbl_t2_6;
        private System.Windows.Forms.Label lbl_subtitle2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_t1_1;
        private System.Windows.Forms.Label lbl_t1_3;
        private System.Windows.Forms.Label lbl_subtitle1;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lbl_t1_4;
        private System.Windows.Forms.Label lbl_t1_2;
    }
}