﻿namespace ECB_APP
{
    partial class frm_domestic_Cal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_title = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_input = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txt_units = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_cla = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.pnl_result = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbl_unit_limit_1 = new System.Windows.Forms.Label();
            this.lbl_8 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.lbl_7 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.lbl_6 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lbl_unit_limit_6 = new System.Windows.Forms.Label();
            this.lbl_5 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.lbl_unit_limit_5 = new System.Windows.Forms.Label();
            this.lbl_4 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lbl_unit_limit_4 = new System.Windows.Forms.Label();
            this.lbl_3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_unit_limit_3 = new System.Windows.Forms.Label();
            this.lbl_2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_unit_limit_2 = new System.Windows.Forms.Label();
            this.lbl_1 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.pnl_title.SuspendLayout();
            this.pnl_input.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnl_result.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_title
            // 
            this.pnl_title.BackColor = System.Drawing.Color.Black;
            this.pnl_title.Controls.Add(this.label2);
            this.pnl_title.Controls.Add(this.label1);
            this.pnl_title.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_title.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.pnl_title.Location = new System.Drawing.Point(0, 0);
            this.pnl_title.Name = "pnl_title";
            this.pnl_title.Size = new System.Drawing.Size(791, 58);
            this.pnl_title.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Arial Black", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(0, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(791, 22);
            this.label2.TabIndex = 1;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Arial Black", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(791, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "DOMESTIC PURPOSE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_input
            // 
            this.pnl_input.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(25)))), ((int)(((byte)(25)))), ((int)(((byte)(25)))));
            this.pnl_input.Controls.Add(this.panel2);
            this.pnl_input.Controls.Add(this.panel1);
            this.pnl_input.Controls.Add(this.label3);
            this.pnl_input.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnl_input.Location = new System.Drawing.Point(0, 58);
            this.pnl_input.Name = "pnl_input";
            this.pnl_input.Size = new System.Drawing.Size(791, 58);
            this.pnl_input.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.txt_units);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(339, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(330, 58);
            this.panel2.TabIndex = 4;
            // 
            // txt_units
            // 
            this.txt_units.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txt_units.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_units.Location = new System.Drawing.Point(6, 20);
            this.txt_units.Name = "txt_units";
            this.txt_units.Size = new System.Drawing.Size(318, 23);
            this.txt_units.TabIndex = 0;
            this.txt_units.Text = "0";
            this.txt_units.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txt_units.Click += new System.EventHandler(this.txt_units_Click);
            this.txt_units.TextChanged += new System.EventHandler(this.txt_units_TextChanged);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btn_cla);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel1.Location = new System.Drawing.Point(669, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(122, 58);
            this.panel1.TabIndex = 3;
            // 
            // btn_cla
            // 
            this.btn_cla.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_cla.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cla.Location = new System.Drawing.Point(8, 15);
            this.btn_cla.Name = "btn_cla";
            this.btn_cla.Size = new System.Drawing.Size(104, 32);
            this.btn_cla.TabIndex = 0;
            this.btn_cla.Text = "CALCULATE ";
            this.btn_cla.UseVisualStyleBackColor = true;
            this.btn_cla.Click += new System.EventHandler(this.btn_cla_Click);
            // 
            // label3
            // 
            this.label3.Dock = System.Windows.Forms.DockStyle.Left;
            this.label3.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Location = new System.Drawing.Point(0, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(339, 58);
            this.label3.TabIndex = 2;
            this.label3.Text = "No of Units Consumed in last 30 days";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnl_result
            // 
            this.pnl_result.Controls.Add(this.tableLayoutPanel1);
            this.pnl_result.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnl_result.Location = new System.Drawing.Point(0, 116);
            this.pnl_result.Name = "pnl_result";
            this.pnl_result.Size = new System.Drawing.Size(791, 404);
            this.pnl_result.TabIndex = 3;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.11393F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 7.341772F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.Controls.Add(this.lbl_unit_limit_1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbl_8, 2, 7);
            this.tableLayoutPanel1.Controls.Add(this.label26, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.label25, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.lbl_7, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.label23, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label22, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.lbl_6, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.label20, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_unit_limit_6, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.lbl_5, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.label17, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_unit_limit_5, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.lbl_4, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.label13, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_unit_limit_4, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.lbl_3, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.label10, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_unit_limit_3, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lbl_2, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.label7, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_unit_limit_2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.lbl_1, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label16, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 8;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.5F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(791, 404);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // lbl_unit_limit_1
            // 
            this.lbl_unit_limit_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_unit_limit_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_unit_limit_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_unit_limit_1.Location = new System.Drawing.Point(0, 0);
            this.lbl_unit_limit_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_unit_limit_1.Name = "lbl_unit_limit_1";
            this.lbl_unit_limit_1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_unit_limit_1.Size = new System.Drawing.Size(468, 50);
            this.lbl_unit_limit_1.TabIndex = 24;
            this.lbl_unit_limit_1.Text = "Charge for first 30 Units (Rs)";
            this.lbl_unit_limit_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_8
            // 
            this.lbl_8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_8.Location = new System.Drawing.Point(526, 350);
            this.lbl_8.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_8.Name = "lbl_8";
            this.lbl_8.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_8.Size = new System.Drawing.Size(265, 54);
            this.lbl_8.TabIndex = 23;
            this.lbl_8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lbl_8.Click += new System.EventHandler(this.lbl_8_Click);
            // 
            // label26
            // 
            this.label26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(468, 350);
            this.label26.Margin = new System.Windows.Forms.Padding(0);
            this.label26.Name = "label26";
            this.label26.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label26.Size = new System.Drawing.Size(58, 54);
            this.label26.TabIndex = 22;
            this.label26.Text = "=";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(0, 350);
            this.label25.Margin = new System.Windows.Forms.Padding(0);
            this.label25.Name = "label25";
            this.label25.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label25.Size = new System.Drawing.Size(468, 54);
            this.label25.TabIndex = 21;
            this.label25.Text = "Total Charge (Rs)";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_7
            // 
            this.lbl_7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_7.Location = new System.Drawing.Point(526, 300);
            this.lbl_7.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_7.Name = "lbl_7";
            this.lbl_7.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_7.Size = new System.Drawing.Size(265, 50);
            this.lbl_7.TabIndex = 20;
            this.lbl_7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label23
            // 
            this.label23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(468, 300);
            this.label23.Margin = new System.Windows.Forms.Padding(0);
            this.label23.Name = "label23";
            this.label23.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label23.Size = new System.Drawing.Size(58, 50);
            this.label23.TabIndex = 19;
            this.label23.Text = "=";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(0, 300);
            this.label22.Margin = new System.Windows.Forms.Padding(0);
            this.label22.Name = "label22";
            this.label22.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label22.Size = new System.Drawing.Size(468, 50);
            this.label22.TabIndex = 18;
            this.label22.Text = "Fixed Charges (Rs)";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_6
            // 
            this.lbl_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_6.Location = new System.Drawing.Point(526, 250);
            this.lbl_6.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_6.Name = "lbl_6";
            this.lbl_6.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_6.Size = new System.Drawing.Size(265, 50);
            this.lbl_6.TabIndex = 17;
            this.lbl_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(468, 250);
            this.label20.Margin = new System.Windows.Forms.Padding(0);
            this.label20.Name = "label20";
            this.label20.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label20.Size = new System.Drawing.Size(58, 50);
            this.label20.TabIndex = 16;
            this.label20.Text = "=";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_unit_limit_6
            // 
            this.lbl_unit_limit_6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_unit_limit_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_unit_limit_6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_unit_limit_6.Location = new System.Drawing.Point(0, 250);
            this.lbl_unit_limit_6.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_unit_limit_6.Name = "lbl_unit_limit_6";
            this.lbl_unit_limit_6.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_unit_limit_6.Size = new System.Drawing.Size(468, 50);
            this.lbl_unit_limit_6.TabIndex = 15;
            this.lbl_unit_limit_6.Text = "Charge above 180 Units (Rs)";
            this.lbl_unit_limit_6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_5
            // 
            this.lbl_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_5.Location = new System.Drawing.Point(526, 200);
            this.lbl_5.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_5.Name = "lbl_5";
            this.lbl_5.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_5.Size = new System.Drawing.Size(265, 50);
            this.lbl_5.TabIndex = 14;
            this.lbl_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(468, 200);
            this.label17.Margin = new System.Windows.Forms.Padding(0);
            this.label17.Name = "label17";
            this.label17.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label17.Size = new System.Drawing.Size(58, 50);
            this.label17.TabIndex = 13;
            this.label17.Text = "=";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_unit_limit_5
            // 
            this.lbl_unit_limit_5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_unit_limit_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_unit_limit_5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_unit_limit_5.Location = new System.Drawing.Point(0, 200);
            this.lbl_unit_limit_5.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_unit_limit_5.Name = "lbl_unit_limit_5";
            this.lbl_unit_limit_5.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_unit_limit_5.Size = new System.Drawing.Size(468, 50);
            this.lbl_unit_limit_5.TabIndex = 12;
            this.lbl_unit_limit_5.Text = "Charge between 121 - 180 Units (Rs)";
            this.lbl_unit_limit_5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_4
            // 
            this.lbl_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_4.Location = new System.Drawing.Point(526, 150);
            this.lbl_4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_4.Name = "lbl_4";
            this.lbl_4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_4.Size = new System.Drawing.Size(265, 50);
            this.lbl_4.TabIndex = 11;
            this.lbl_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label13
            // 
            this.label13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(468, 150);
            this.label13.Margin = new System.Windows.Forms.Padding(0);
            this.label13.Name = "label13";
            this.label13.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label13.Size = new System.Drawing.Size(58, 50);
            this.label13.TabIndex = 10;
            this.label13.Text = "=";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_unit_limit_4
            // 
            this.lbl_unit_limit_4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_unit_limit_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_unit_limit_4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_unit_limit_4.Location = new System.Drawing.Point(0, 150);
            this.lbl_unit_limit_4.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_unit_limit_4.Name = "lbl_unit_limit_4";
            this.lbl_unit_limit_4.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_unit_limit_4.Size = new System.Drawing.Size(468, 50);
            this.lbl_unit_limit_4.TabIndex = 9;
            this.lbl_unit_limit_4.Text = "Charge between 91 - 120 Units (Rs)";
            this.lbl_unit_limit_4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_3
            // 
            this.lbl_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_3.Location = new System.Drawing.Point(526, 100);
            this.lbl_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_3.Name = "lbl_3";
            this.lbl_3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_3.Size = new System.Drawing.Size(265, 50);
            this.lbl_3.TabIndex = 8;
            this.lbl_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label10
            // 
            this.label10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(468, 100);
            this.label10.Margin = new System.Windows.Forms.Padding(0);
            this.label10.Name = "label10";
            this.label10.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label10.Size = new System.Drawing.Size(58, 50);
            this.label10.TabIndex = 7;
            this.label10.Text = "=";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_unit_limit_3
            // 
            this.lbl_unit_limit_3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_unit_limit_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_unit_limit_3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_unit_limit_3.Location = new System.Drawing.Point(0, 100);
            this.lbl_unit_limit_3.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_unit_limit_3.Name = "lbl_unit_limit_3";
            this.lbl_unit_limit_3.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_unit_limit_3.Size = new System.Drawing.Size(468, 50);
            this.lbl_unit_limit_3.TabIndex = 6;
            this.lbl_unit_limit_3.Text = "Charge between 61 - 90 Units (Rs)";
            this.lbl_unit_limit_3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_2
            // 
            this.lbl_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_2.Location = new System.Drawing.Point(526, 50);
            this.lbl_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_2.Name = "lbl_2";
            this.lbl_2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_2.Size = new System.Drawing.Size(265, 50);
            this.lbl_2.TabIndex = 5;
            this.lbl_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(468, 50);
            this.label7.Margin = new System.Windows.Forms.Padding(0);
            this.label7.Name = "label7";
            this.label7.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label7.Size = new System.Drawing.Size(58, 50);
            this.label7.TabIndex = 4;
            this.label7.Text = "=";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_unit_limit_2
            // 
            this.lbl_unit_limit_2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_unit_limit_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_unit_limit_2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_unit_limit_2.Location = new System.Drawing.Point(0, 50);
            this.lbl_unit_limit_2.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_unit_limit_2.Name = "lbl_unit_limit_2";
            this.lbl_unit_limit_2.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_unit_limit_2.Size = new System.Drawing.Size(468, 50);
            this.lbl_unit_limit_2.TabIndex = 3;
            this.lbl_unit_limit_2.Text = "Charge between 31 - 60 Units (Rs)";
            this.lbl_unit_limit_2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lbl_1
            // 
            this.lbl_1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbl_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_1.Location = new System.Drawing.Point(526, 0);
            this.lbl_1.Margin = new System.Windows.Forms.Padding(0);
            this.lbl_1.Name = "lbl_1";
            this.lbl_1.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.lbl_1.Size = new System.Drawing.Size(265, 50);
            this.lbl_1.TabIndex = 2;
            this.lbl_1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(468, 0);
            this.label16.Margin = new System.Windows.Forms.Padding(0);
            this.label16.Name = "label16";
            this.label16.Padding = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.label16.Size = new System.Drawing.Size(58, 50);
            this.label16.TabIndex = 1;
            this.label16.Text = "=";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // frm_domestic_Cal
            // 
            this.AcceptButton = this.btn_cla;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 520);
            this.Controls.Add(this.pnl_result);
            this.Controls.Add(this.pnl_input);
            this.Controls.Add(this.pnl_title);
            this.Name = "frm_domestic_Cal";
            this.Text = "frm_domestic_Cal";
            this.pnl_title.ResumeLayout(false);
            this.pnl_input.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.pnl_result.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_title;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnl_input;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txt_units;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_cla;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel pnl_result;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lbl_8;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label lbl_7;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lbl_6;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lbl_unit_limit_6;
        private System.Windows.Forms.Label lbl_5;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lbl_unit_limit_5;
        private System.Windows.Forms.Label lbl_4;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lbl_unit_limit_4;
        private System.Windows.Forms.Label lbl_3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_unit_limit_3;
        private System.Windows.Forms.Label lbl_2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbl_unit_limit_2;
        private System.Windows.Forms.Label lbl_1;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lbl_unit_limit_1;
    }
}